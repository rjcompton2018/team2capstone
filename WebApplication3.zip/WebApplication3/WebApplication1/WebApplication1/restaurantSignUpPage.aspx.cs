﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class restaurantSignUpPage : sqlPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            getReader("SELECT * FROM Restaurant WHERE Email=@value1", txtEmail.Text);
            if (!reader.HasRows)
            {
                reader.Close();
                object[] parameters = { txtEmail.Text, txtName.Value, txtPassword.Value };
                executeVoidSQLQuery("INSERT INTO Restaurant (Email, Restaurant_Name, Password) VALUES(@value1, @value2, @value3)", parameters);
            }
            Console.WriteLine("Hello world");
        }
    }
}