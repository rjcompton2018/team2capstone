<?php
	//This is to add to the sql and to connect it
	$username = "root";
	$password = "";
	$hostname = "localhost";
	$dbname = "users";
	$connection = mysqli_connect($hostname, $username, $password, $dbname);
	
	//if the user and email are there then create it
	if(isset($_POST['user']) && isset($_POST['email'])){
		$user = $_POST['user'];
		$email = $_POST['email'];
		//query selects from table newusers where username equals $user
		$query = "SELECT * FROM newusers WHERE username='$user'";
		$result = mysqli_query($connection, $query);
		
		if(mysqli_num_rows($result) > 0 ) { //check if there is already an entry for that username
			echo "That Username already exists!";
		}else{
			//add user and email into sql
			$query = "INSERT INTO newusers (username, email) VALUES ('$user', '$email')";
			$result = mysqli_query($connection, $query);
			header("location: ../ReServe-Login.html");
		}
		
		
	}
	mysqli_close($connection);
	//close the connection
?>

<html lang="en">
		<head>
<style>
<?php include 'assets/css/desktop.css'; ?>
</style>
<meta charset="utf-8">
		<title>
			Nature's Aid Semester Project
		</title>
		<!--Creates Leaf Icon in Tab-->
		<link rel="shortcut icon" href="../images/6iroxeqrT.png"/>
		<!--Links to CSS sheets-->
			<link rel="stylesheet" type="text/css" href="assets/css/CODE-S.css">
			<link rel="stylesheet" href="../css/desktop.css">
			<link rel="stylesheet" href="../css/laptop.css">
			<link rel="stylesheet" href="../css/tablet.css">
			<link rel="stylesheet" href="../css/phone.css">
		</head>
<body> 
		<div class="menu">
		<!--Nav bar links to other parts of the website and creates a dropdown list when shrunk-->
			<ul>
			<li class="dropdown">
			<label class="buttonmenu"><label class="dropbtn">Nature's Aid</label></label>
			<div class="dropdown-content">
				<a class="button" href="../../Main.html">Main</a>
				<a class="button" href="../../About.html">About</a>
				<a class="button" href="../../Schedule.html">Schedule</a>
				<a class="button" href="../../Participate.html">Participate</a>
				<a class="button" href="../../Location.html">Location</a>
			</div>
				</li>
				</ul>
			</div>	
	<!--Signup form where user can enter their username and email-->
	<div class="article"><center>
		<h6>Signup for Nature's Aid's volunteer newsletter!</h6>
			<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
				<p>Username:</p><input type="text" name="user" required text="text">
				<p>Email:</p><input type="email" name="email" required text="text">
				<br>
				<input type="submit" value="Signup" id="sub">
				<br>
			</form>
	</center></div>
			<!--This is the footer, it gives the address and copyright information of the website-->
			<div class="footer">
			&copy; Copyright 2018 - Nature's Aid - 999.999.999 - 310 Waldon Rd. Orion Charter Township, MI 47585
		</div>
	</body>
</html>