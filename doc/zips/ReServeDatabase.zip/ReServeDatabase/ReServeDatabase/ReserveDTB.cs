﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReServeDatabase
{
    public class ReserveDTB
    {
        /*main class that the database team will 
        be maintained during the whole project*/

        // Anyone can call this method below
        public Boolean CompareInfo(string emailAddress, string Password)
        {/* Method statements here
            This method should go through all the rows in the table
            and check if the email address and password match 
            any existed restaurants. If it does, return yes, 
            else return no.*/
        }
    }
}
