package com.alps.alna172991.reserve_gui;

public class Constants {

    public static final float SHAKE_THRESHOLD_GRAVITY = 5.4F;
    public static final int SHAKE_SLOP_TIME_MS = 500;
    public class Actions{
        public static final String ACTION_LOGIN = "com.alps.alna172991.reserve_gui.ACTION_LOGIN";
    }
}
