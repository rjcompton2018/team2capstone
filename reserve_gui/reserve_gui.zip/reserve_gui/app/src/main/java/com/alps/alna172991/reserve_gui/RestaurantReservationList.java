package com.alps.alna172991.reserve_gui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RestaurantReservationList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_reservation_list);
    }
}
