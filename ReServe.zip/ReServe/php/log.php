<?php
//This is to add to the sql and to connect it
	$username = "root";
	$password = "";
	$hostname = "localhost";
	$dbname = "users";
//Establish connection and pass variables
	$connection = mysqli_connect($hostname, $username, $password, $dbname);
	
	$myuser = $_POST['user'];
	$myemail = $_POST['email'];
	

//The query selects from table called newusers where username is $user and $email
	$query = "SELECT * FROM newusers WHERE username='$myuser' AND email='$myemail'";
	$result = mysqli_query($connection, $query); //takes result and equals to mysql query with connection 
	$count = mysqli_num_rows($result); //counts the number of rows
//Closes the connection.
	mysqli_close($connection);
//if the count is 1 then the session starts. The session equals my user else if the username and email don't match then error message pops up.
	if($count==1){
		
        session_start();
		
        $_SESSION['user'] = $myuser; 
		header("location:successful.php");
	}else{
		echo 'Incorrect Username or Email';
	}	
	
?>